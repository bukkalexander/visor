# @lab/react-components

Private React/TypeScript components for sortable cards and nested rows. Requires React and React DOM >=19. Component APIs and their guides are versioned together.

Install the selected tarball from your app's tracked `vendor/` directory using its existing package manager. With npm:

```sh
npm install ./vendor/lab-react-components-0.1.0.tgz
```

Import `@lab/react-components/styles.css` once. The app supplies its content and controlled state; the components supply interactions.

- [SortableCollection](docs/collection.md): grid/list activity cards, persistent editing, insertion, and optional edit-only removal.
- [SortableOutline](docs/outline.md): hierarchical checklist/bullet rows, handle dragging, complete subtree movement, and swipe indent/outdent.

The filename above is an example; use your selected version. Keep the tarball and lockfile in the app so builds do not need a library checkout or private GitHub credentials. Do not install the live workspace through a symlink. Upgrade explicitly by replacing the tarball dependency and checking the app; keep the bundled guides matching the installed version.
