/** Side-effect import for the separately exported interaction stylesheet. */
export {};
