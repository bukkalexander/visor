# SortableOutline

Use for fully expanded nested checklist or bullet rows, with subtree movement and indent/outdent. React and React DOM >=19 are required. Import `@lab/react-components/styles.css` once at the application's CSS entrypoint. In frameworks with server components, render this interaction inside a client component.

```tsx
import { useState } from "react";
import { SortableOutline, type OutlineNode } from "@lab/react-components";
import "@lab/react-components/styles.css";

export function Checklist() {
  const [nodes, setNodes] = useState<OutlineNode<string>[]>([
    {
      id: "trip",
      data: "Plan trip",
      children: [{ id: "tickets", data: "Book tickets", children: [] }],
    },
    { id: "travel", data: "Travel", children: [] },
  ]);
  return (
    <SortableOutline
      nodes={nodes}
      onNodesChange={setNodes}
      renderRow={(node) => (
        <label>
          <input type="checkbox" /> {node.data}
        </label>
      )}
    />
  );
}
```

For bullets, supply bullet content in `renderRow`; movement does not require checkboxes. For controlled checked state, use an application payload such as `{ title, checked }` and update it immutably from the row's checkbox handler. `OutlineNode<T>` is `{ id: string; data: T; children: OutlineNode<T>[] }`. IDs must be stable and unique across the whole tree.

## Contract

Required props: controlled `nodes`, `onNodesChange`, and `renderRow`. Keep immutable input references stable between meaningful data changes. Callbacks fire only on a changed valid commit. External data replacement, interrupted input, Escape, and outside drops cancel dragging without a callback. The app owns content, checked state, persistence, and any removal action. There is no outline `onRemove` prop or persistent editing mode.

The library supplies a six-dot handle; hold it for `holdDuration` milliseconds (250 by default), tolerating 5 px movement. The entire subtree moves. Only the proposed subtree is shown at the destination; there is no floating overlay. Vertical movement sets insertion; horizontal movement snaps depth by `indentWidth` pixels (24 by default). Parentage follows the nearest preceding row at the required depth, with first position forced to root and no cycles or fixed maximum depth. Descendant relative depths are preserved.

Swiping row content right indents one level; left outdents one level. Swipes require horizontal intent and at least `max(32, indentWidth * 1.5)` px before release. Outdenting moves the subtree after its parent's remaining children. Invalid or unchanged placements do not fire a callback. Vertical movement allows native scrolling. Embedded buttons, inputs, links, editable content, and `data-no-drag` regions retain their normal behavior and do not start swipes. Set `swipeToIndent={false}` to disable swipes.

Rendered row content becomes inert only during handle dragging; idle checkboxes and client-designed removal buttons remain available. Handle and swipe surfaces disable text selection and iOS callouts. Native selection/magnifier and scrolling still need physical-device verification.

Keyboard on a handle: Space/Enter picks up or drops, Up/Down changes insertion, Left/Right changes depth, Escape cancels. Position and depth are announced. `feedback` supports `shadeStrength`, best-effort `haptics`, and `hapticDuration`; haptics are off by default. Use the stylesheet's `--sort-*` variables for interaction styling and the app's own styles for row content.

Collapsed branches, virtualization, and cross-collection transfers are not implemented.
