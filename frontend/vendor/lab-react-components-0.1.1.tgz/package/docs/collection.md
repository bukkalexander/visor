# SortableCollection

Use for one controlled ordered array displayed as a responsive grid or vertical list. React and React DOM >=19 are required. Import `@lab/react-components/styles.css` once at the application's CSS entrypoint. In frameworks with server components, render the interactive component inside a client component.

```tsx
import { useState } from "react";
import { SortableCollection } from "@lab/react-components";
import "@lab/react-components/styles.css";

export function Activities() {
  const [items, setItems] = useState([
    { id: "walk", title: "Morning walk" },
    { id: "read", title: "Read a chapter" },
  ]);
  return (
    <SortableCollection
      items={items}
      getId={(item) => item.id}
      renderItem={(item) => (
        <article onClick={() => console.log(item.id)}>{item.title}</article>
      )}
      onItemsChange={setItems}
      layout="grid"
      onRemove={(item) =>
        setItems((current) =>
          current.filter((candidate) => candidate.id !== item.id),
        )
      }
      removeLabel={(item) => "Remove " + item.title}
    />
  );
}
```

## Contract

Required props: `items`, `getId`, `renderItem`, and `onItemsChange`. IDs are stable, unique strings. Keep the immutable items reference stable until application data actually changes: external replacement during dragging cancels the session. The change callback fires only for a changed, valid committed placement; cancellation does not fire it. The app owns persistence and content styling.

`layout` is `"grid"` (default) or `"list"`; switching layout preserves ordering and editing. `editing`/`onEditingChange` optionally control editing. The library renders Edit order/Done. A click outside a card, including a collection gap, exits editing; mark external controls `data-sort-edit-exempt` or configure `editExemptSelector` to keep editing active.

Normal content clicks work outside editing. Holding a card for 250 ms enters editing and starts dragging. In editing, mouse/pen use 5 px movement and touch uses a 35 ms hold; holds tolerate 5 px movement. `activation` can override `hold`, `touchHold`, `distance`, and `tolerance` (milliseconds/pixels). Nested buttons, links, inputs, and `data-no-drag` regions do not activate dragging. Rendered content becomes inert during editing, so input focus and content actions are unavailable until Done. Card text disables selection and iOS callouts. Optional `onRemove` renders X only in editing; removal is the app's callback, not a reorder commit.

Dragging shows a moving card and an empty destination space. Reordering uses insertion, a 12% item-size position margin bounded to 8–24 px, and 80 ms delayed/280 ms animations. Outside drops, Escape, interrupted input, and external data changes cancel. Edit mode remains active after dropping or canceling a drag. Reduced motion disables animation.

Keyboard: focus a card; Space/Enter picks up or drops, arrows move its insertion position, Escape cancels (or exits idle editing). Proposed placements are announced. `feedback` supports `overlayOpacity`, best-effort `haptics`, and `hapticDuration`; haptics are off by default.

Style app content separately. Interaction colors and spacing use `--sort-bg`, `--sort-fg`, `--sort-muted`, `--sort-border`, `--sort-accent`, `--sort-space`, and `--sort-shadow`. Verify native holds, scrolling, and the text magnifier on physical mobile devices; browser emulation does not establish real-device parity.
